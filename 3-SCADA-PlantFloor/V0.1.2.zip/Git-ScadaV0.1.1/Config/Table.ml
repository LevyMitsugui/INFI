�
Language0�Language1
Conveyor1�Conveyor1
Conveyor2�Conveyor2
Conveyor3�Conveyor3
conveyor1�conveyor1
conveyor2�conveyor2
conveyor3�conveyor3
sensor1�sensor1
sensor2�sensor2
STOP 1�STOP 1
Conveyor 1 overloaded!�Conveyor 1 overloaded!
Conveyor 2 Overload!�Conveyor 2 Overload!
Alarms�Alarms
Active�Active
Ack�Ack
Message�Message
Date�Date
Time�Time
Class 1�Class 1
Class 2�Class 2
To ack�To ack
Excluded�Excluded
Alarm History�Alarm History
Start date�Start date
Start time�Start time
End date�End date
End time�End time
Conveyor 1 switched on.�Conveyor 1 switched on.
Conveyor 2 switched on.�Conveyor 2 switched on.
Events�Events
Close�Close
close�close
AT1_in1�AT1_in1
AT1_out1�AT1_out1
Blink ON�Blink ON
Blink OFF�Blink OFF
Cell1_Mtop_m�Cell1_Mtop_m
conveyor4�conveyor4
Cell1_Mbot_m�Cell1_Mbot_m
AT2_in1�AT2_in1
AT2_out1�AT2_out1
Roll1a�Roll1a
Roll1b�Roll1b
Roll1c�Roll1c
Roll1e�Roll1e
Roll1d�Roll1d
Roll1f�Roll1f
Cell1_Mtop_rot_m�Cell1_Mtop_rot_m
Cell1_Mtop_tool�Cell1_Mtop_tool
Cell1_Mbot_rot_m�Cell1_Mbot_rot_m
Cell1_Mbot_tool�Cell1_Mbot_tool
Machine (M1)�Machine (M1)
Mtop�Mtop
Mbot�Mbot
Machine (M2)�Machine (M2)
T1�T1
T2�T2
T3�T3
Automatic�Automatic
Maintenance�Maintenance
Manual�Manual
