�
Language0�Language1
Conveyor1�Conveyor1
Conveyor2�Conveyor2
Conveyor3�Conveyor3
conveyor1�conveyor1
conveyor2�conveyor2
conveyor3�conveyor3
sensor1�sensor1
sensor2�sensor2
STOP 1�STOP 1
Conveyor 1 overloaded!�Conveyor 1 overloaded!
Conveyor 2 Overload!�Conveyor 2 Overload!
Alarms�Alarms
Active�Active
Ack�Ack
Message�Message
Date�Date
Time�Time
Class 1�Class 1
Class 2�Class 2
To ack�To ack
Excluded�Excluded
Alarm History�Alarm History
Start date�Start date
Start time�Start time
End date�End date
End time�End time
Conveyor 1 switched on.�Conveyor 1 switched on.
Conveyor 2 switched on.�Conveyor 2 switched on.
Events�Events
Close�Close
close�close
AT1_in1�AT1_in1
AT1_out1�AT1_out1
Blink ON�Blink ON
Blink OFF�Blink OFF
Cell1_Mtop_m�Cell1_Mtop_m
conveyor4�conveyor4
Cell1_Mbot_m�Cell1_Mbot_m
AT2_in1�AT2_in1
AT2_out1�AT2_out1
Roll1a�Roll1a
Roll1b�Roll1b
Roll1c�Roll1c
Roll1e�Roll1e
Roll1d�Roll1d
Roll1f�Roll1f
Cell1_Mtop_rot_m�Cell1_Mtop_rot_m
Cell1_Mtop_tool�Cell1_Mtop_tool
Cell1_Mbot_rot_m�Cell1_Mbot_rot_m
Cell1_Mbot_tool�Cell1_Mbot_tool
Machine (M1)�Machine (M1)
Mtop�Mtop
Mbot�Mbot
Machine (M2)�Machine (M2)
T1�T1
T2�T2
T3�T3
Automatic�Automatic
Maintenance�Maintenance
Manual�Manual
M1_Conveyor�M1_Conveyor
Change Tool�Change Tool
Logs�Logs
Select Operation Mode�Select Operation Mode
Operation Mode�Operation Mode
Return to�Return to
Piece Done�Piece Done
Neg�Neg
Pos�Pos
Machine 1 tool switched on.�Machine 1 tool switched on.
Machine 2 tool switched on.�Machine 2 tool switched on.
Machine 1 tool turret negative rotation switched on.�Machine 1 tool turret negative rotation switched on.
Machine 1 tool turret positive rotation switched on.�Machine 1 tool turret positive rotation switched on.
Machine 2 tool turret negative rotation switched on.�Machine 2 tool turret negative rotation switched on.
Machine 2 tool turret positive rotation switched on.�Machine 2 tool turret positive rotation switched on.
Machine 1 entered in maintenance mode!�Machine 1 entered in maintenance mode!
Machine 2 entered in maintenance mode!�Machine 2 entered in maintenance mode!
Machine 1 entered in automatic mode.�Machine 1 entered in automatic mode.
Machine 2 entered in automatic mode.�Machine 2 entered in automatic mode.
Machine 1 manual piece transformation done.�Machine 1 manual piece transformation done.
Machine 2 manual piece transformation done.�Machine 2 manual piece transformation done.
Machine 1 entered in manual mode.�Machine 1 entered in manual mode.
Machine 2 entered in manual mode.�Machine 2 entered in manual mode.
Machine 1 tool in place.�Machine 1 tool in place.
Machine 1 left maintenance mode!�Machine 1 left maintenance mode!
Machine 2 left maintenance mode!�Machine 2 left maintenance mode!
Piece entered in Cell1.�Piece entered in Cell1.
Piece arrived at Machine 1, and is ready to be transformed.�Piece arrived at Machine 1, and is ready to be transformed.
Piece arrived at Machine 2, and is ready to be transformed.�Piece arrived at Machine 2, and is ready to be transformed.
Piece left Cell1.�Piece left Cell1.
Machine1 no tool detected.�Machine1 no tool detected.
Machine2 no tool detected.�Machine2 no tool detected.
Machine 1 tool switched off.�Machine 1 tool switched off.
Machine 2 tool switched off.�Machine 2 tool switched off.
Machine 1 tool turret negative rotation switched off.�Machine 1 tool turret negative rotation switched off.
Machine 1 tool turret positive rotation switched off.�Machine 1 tool turret positive rotation switched off.
Machine 2 tool turret negative rotation switched off.�Machine 2 tool turret negative rotation switched off.
Machine 2 tool turret positive rotation switched off.�Machine 2 tool turret positive rotation switched off.
Wharehouse1 out conveyor switched on.�Wharehouse1 out conveyor switched on.
Machine1 conveyor switched on.�Machine1 conveyor switched on.
Middle Conveyor switched on.�Middle Conveyor switched on.
Machine2 conveyor switched on.�Machine2 conveyor switched on.
Wharehouse2 in conveyor switched on.�Wharehouse2 in conveyor switched on.
Wharehouse1 out conveyor switched off.�Wharehouse1 out conveyor switched off.
Machine1 conveyor switched off.�Machine1 conveyor switched off.
Middle conveyor switched off.�Middle conveyor switched off.
Machine2 conveyor switched off.�Machine2 conveyor switched off.
Wharehouse2 in conveyor switched off.�Wharehouse2 in conveyor switched off.
Conv_WH1_in�Conv_WH1_in
Conv_WH1_out�Conv_WH1_out
Conv_Mid�Conv_Mid
Conv_WH2_in�Conv_WH2_in
Conv_WH2_out�Conv_WH2_out
Conv_Mtop�Conv_Mtop
Conv_Mbot�Conv_Mbot
Return M1 to�Return M1 to
Piece ready to leave Cell1.�Piece ready to leave Cell1.
Piece at Machine1 is ready but won't advance!�Piece at Machine1 is ready but won't advance!
Piece at Machine2 is ready but won't advance!�Piece at Machine2 is ready but won't advance!
