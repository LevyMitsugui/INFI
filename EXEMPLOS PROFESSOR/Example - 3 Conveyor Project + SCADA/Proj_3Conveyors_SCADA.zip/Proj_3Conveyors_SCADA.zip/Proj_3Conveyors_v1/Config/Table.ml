�
Language0�Language1
Conveyor1�Conveyor1
Conveyor2�Conveyor2
Conveyor3�Conveyor3
conveyor1�conveyor1
conveyor2�conveyor2
conveyor3�conveyor3
sensor1�sensor1
sensor2�sensor2
STOP 1�STOP 1
Conveyor 1 overloaded!�Conveyor 1 overloaded!
Conveyor 2 Overload!�Conveyor 2 Overload!
Alarms�Alarms
Active�Active
Ack�Ack
Message�Message
Date�Date
Time�Time
Class 1�Class 1
Class 2�Class 2
To ack�To ack
Excluded�Excluded
Alarm History�Alarm History
Start date�Start date
Start time�Start time
End date�End date
End time�End time
Conveyor 1 switched on.�Conveyor 1 switched on.
Conveyor 2 switched on.�Conveyor 2 switched on.
Events�Events
Close�Close
close�close
